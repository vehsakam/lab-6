function productOfThree(a, b, c) {
  let product = a * b * c;
  console.log("Product of", a, b, c, "is", product);
  return product;
}

function greatestNumber(a, b) {
  if (a > b) {
    console.log(a, "is greatest");
    return a;
  }
  console.log(b, "is greatest");
  return b;
}

function helloWorld() {
  console.log("Hello World");
  console.log("Hello World");
  console.log("Hello World");
}

productOfThree(1, 2, 3);
greatestNumber(1, 2);
greatestNumber(100, 1000);
helloWorld();
